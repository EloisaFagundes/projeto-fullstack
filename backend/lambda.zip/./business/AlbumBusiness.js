"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumBusiness = void 0;
const User_1 = require("../model/User");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const NotFoundError_1 = require("../errors/NotFoundError");
const Album_1 = require("../model/Album");
class AlbumBusiness {
    constructor(albumDatabase, userDatabase, genreDatabase, tokenGenerator, idGenerator) {
        this.albumDatabase = albumDatabase;
        this.userDatabase = userDatabase;
        this.genreDatabase = genreDatabase;
        this.tokenGenerator = tokenGenerator;
        this.idGenerator = idGenerator;
    }
    createAlbum(token, name, genresInfo) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.tokenGenerator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if ((userLogged === null || userLogged === void 0 ? void 0 : userLogged.getRole()) !== User_1.UserRole.BAND) {
                throw new NotFoundError_1.NotFoundError("Seu usuário não tem permissão para criar um álbum.");
            }
            if (!name || !token || !genresInfo) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os dados exigidos para cadastrar um novo álbum.");
            }
            const id = this.idGenerator.generate();
            const bandId = userLogged.getId();
            const newAlbum = new Album_1.Album(id, bandId, name);
            const findByName = yield this.albumDatabase.getAlbumByName(name, bandId);
            if (findByName) {
                throw new InvalidParameterError_1.InvalidParameterError("Você já possui um álbum com esse nome.");
            }
            const genres = yield this.genreDatabase.getAllMusicalGenres();
            for (const genre of genresInfo) {
                let find = genres.find((find) => find.getId() === genre);
                if (!find) {
                    throw new NotFoundError_1.NotFoundError("Não foi possível encontrar o gênero.");
                }
            }
            yield this.albumDatabase.createAlbum(newAlbum);
            yield this.albumDatabase.createRelatesAlbumAndGenre(newAlbum.getId(), genresInfo);
        });
    }
    getAlbunsByBandId(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.tokenGenerator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if ((userLogged === null || userLogged === void 0 ? void 0 : userLogged.getRole()) !== User_1.UserRole.BAND) {
                throw new NotFoundError_1.NotFoundError("Seu usuário não tem permissão para criar um álbum.");
            }
            if (!userLogged) {
                throw new NotFoundError_1.NotFoundError("Usuário não localizado, efetue login.");
            }
            const albunsList = yield this.albumDatabase.getAlbunsByBandId(userLogged.getId());
            return albunsList;
        });
    }
}
exports.AlbumBusiness = AlbumBusiness;
