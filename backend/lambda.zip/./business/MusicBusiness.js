"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MusicBusiness = void 0;
const User_1 = require("../model/User");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const NotFoundError_1 = require("../errors/NotFoundError");
const Music_1 = require("../model/Music");
const GenericError_1 = require("../errors/GenericError");
class MusicBusiness {
    constructor(musicDatabase, albumDatabase, userDatabase, tokenGenerator, idGenerator) {
        this.musicDatabase = musicDatabase;
        this.albumDatabase = albumDatabase;
        this.userDatabase = userDatabase;
        this.tokenGenerator = tokenGenerator;
        this.idGenerator = idGenerator;
    }
    createMusic(token, albumId, name) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.tokenGenerator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if (!name || !token || !albumId) {
                throw new InvalidParameterError_1.InvalidParameterError("Preencha os dados exigidos para cadastrar uma nova música.");
            }
            if ((userLogged === null || userLogged === void 0 ? void 0 : userLogged.getRole()) !== User_1.UserRole.BAND) {
                throw new NotFoundError_1.NotFoundError("Seu usuário não tem permissão para criar uma música.");
            }
            if (!userLogged) {
                throw new NotFoundError_1.NotFoundError("Usuário não localizado, efetue login.");
            }
            const id = this.idGenerator.generate();
            const findAlbum = yield this.albumDatabase.getAlbumById(albumId);
            if (!findAlbum) {
                throw new NotFoundError_1.NotFoundError("Álbum não encontrado. Selecione um álbum existente ou cadastre um novo álbum.");
            }
            const musicAlbum = yield this.musicDatabase.getMusicsByAlbumId(albumId);
            const findNameMusic = musicAlbum.find((music) => music.getName() === name);
            if (findNameMusic) {
                throw new GenericError_1.GenericError("Música já cadastrada com esse nome. Escolha outro nome para essa música.");
            }
            const music = new Music_1.Music(id, albumId, name);
            yield this.musicDatabase.createMusic(music);
        });
    }
}
exports.MusicBusiness = MusicBusiness;
