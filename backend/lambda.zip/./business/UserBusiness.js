"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserBusiness = void 0;
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const User_1 = require("../model/User");
const NotFoundError_1 = require("../errors/NotFoundError");
const GenericError_1 = require("../errors/GenericError");
class UserBusiness {
    constructor(userDatabase, hashGenerator, tokenGenerator, idGenerator) {
        this.userDatabase = userDatabase;
        this.hashGenerator = hashGenerator;
        this.tokenGenerator = tokenGenerator;
        this.idGenerator = idGenerator;
    }
    login(nicknameOrEmail, password) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!nicknameOrEmail || !password) {
                throw new InvalidParameterError_1.InvalidParameterError("Parâmetros inválidos");
            }
            let user;
            if (nicknameOrEmail.indexOf("@") !== -1) {
                user = yield this.userDatabase.getUserByEmail(nicknameOrEmail);
            }
            else {
                user = yield this.userDatabase.getUserByNickname(nicknameOrEmail);
            }
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Usuário e/ou senha inválidos");
            }
            if (user.getApproved() === false) {
                throw new GenericError_1.GenericError("O usuário precisa de autorização de um administrador para logar.");
            }
            const verifyCorrectPassword = yield this.hashGenerator.compareHash(password, user.getPassword());
            if (!verifyCorrectPassword) {
                throw new InvalidParameterError_1.InvalidParameterError("Usuário e/ou senha inválidos");
            }
            const acessToken = this.tokenGenerator.generate({
                id: user.getId(),
                role: user.getRole(),
            });
            return { acessToken, user };
        });
    }
    signupBand(name, email, nickname, password, description) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !email || !password || !nickname || !description) {
                throw new InvalidParameterError_1.InvalidParameterError("Parâmetros inválidos");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("E-mail inválido");
            }
            if (password.length < 6) {
                throw new InvalidParameterError_1.InvalidParameterError("Senha inválida, a senha deve possuir mais de 6 caracteres.");
            }
            const id = this.idGenerator.generate();
            const role = User_1.UserRole.BAND;
            const hashPassword = yield this.hashGenerator.generateHash(password);
            const user = new User_1.User(id, name, email, nickname, hashPassword, User_1.stringToUserRole(role), false, description);
            yield this.userDatabase.createBandUser(user);
            return { user };
        });
    }
    signupAdmin(name, email, nickname, password, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.tokenGenerator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if ((userLogged === null || userLogged === void 0 ? void 0 : userLogged.getRole()) !== User_1.UserRole.ADMIN) {
                throw new NotFoundError_1.NotFoundError("Seu usuário não tem permissão para acessar essa página.");
            }
            if (!name || !email || !password || !nickname) {
                throw new InvalidParameterError_1.InvalidParameterError("Parâmetros inválidos");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("E-mail inválido");
            }
            if (password.length <= 10) {
                throw new InvalidParameterError_1.InvalidParameterError("Senha inválida, a senha deve possuir mais de 10 caracteres.");
            }
            const id = this.idGenerator.generate();
            const role = User_1.UserRole.ADMIN;
            const hashPassword = yield this.hashGenerator.generateHash(password);
            yield this.userDatabase.createBandUser(new User_1.User(id, name, email, nickname, hashPassword, User_1.stringToUserRole(role), true));
            const acessToken = this.tokenGenerator.generate({ id, role });
            return { acessToken };
        });
    }
    signupUser(name, email, nickname, password, role) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !email || !password || !nickname) {
                throw new InvalidParameterError_1.InvalidParameterError("Parâmetros inválidos");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("E-mail inválido");
            }
            if (password.length < 6) {
                throw new InvalidParameterError_1.InvalidParameterError("Senha inválida, verifique se ea possui mais de 6 caracteres.");
            }
            const id = this.idGenerator.generate();
            const hashPassword = yield this.hashGenerator.generateHash(password);
            const user = new User_1.User(id, name, email, nickname, hashPassword, User_1.stringToUserRole(role), true);
            yield this.userDatabase.createBandUser(user);
            const acessToken = this.tokenGenerator.generate({ id, role });
            return { acessToken, user };
        });
    }
    getAllBandsToBeApproved(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const userInfo = this.tokenGenerator.verify(token);
            const user = yield this.userDatabase.getUserById(userInfo.id);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("Não foi possível encontrar esse usuário. É necessário realizar login.");
            }
            if (user.getRole() !== User_1.UserRole.ADMIN) {
                throw new GenericError_1.GenericError("Seu usuário não ter permissão para vizualizar essa página.");
            }
            const artists = yield this.userDatabase.getAllBandsToBeApproved();
            return artists.map((band) => ({
                id: band.getId(),
                name: band.getName(),
                email: band.getEmail(),
                nickname: band.getNickname(),
                approved: band.getApproved(),
            }));
        });
    }
    approveBand(token, id) {
        return __awaiter(this, void 0, void 0, function* () {
            const userLoggedData = this.tokenGenerator.verify(token);
            const userLogged = yield this.userDatabase.getUserById(userLoggedData.id);
            if ((userLogged === null || userLogged === void 0 ? void 0 : userLogged.getRole()) !== User_1.UserRole.ADMIN) {
                throw new NotFoundError_1.NotFoundError("Seu usuário não tem permissão para acessar essa página.");
            }
            const band = yield this.userDatabase.getUserById(id);
            if (!band) {
                throw new NotFoundError_1.NotFoundError("Artista não encontrado.");
            }
            if (band.getApproved() == true) {
                throw new GenericError_1.GenericError("Esse artista já foi aprovado.");
            }
            yield this.userDatabase.approveBand(id);
        });
    }
}
exports.UserBusiness = UserBusiness;
