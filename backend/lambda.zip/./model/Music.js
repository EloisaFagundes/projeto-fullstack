"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Music = void 0;
class Music {
    constructor(id, albumId, name) {
        this.id = id;
        this.albumId = albumId;
        this.name = name;
    }
    getId() {
        return this.id;
    }
    getAlbumId() {
        return this.albumId;
    }
    getName() {
        return this.name;
    }
}
exports.Music = Music;
