"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRole = exports.stringToUserRole = exports.User = void 0;
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
class User {
    constructor(id, name, email, nickname, password, role, approved, description) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.nickname = nickname;
        this.password = password;
        this.role = role;
        this.approved = approved;
        this.description = description;
    }
    getId() {
        return this.id;
    }
    getName() {
        return this.name;
    }
    getEmail() {
        return this.email;
    }
    getNickname() {
        return this.nickname;
    }
    getPassword() {
        return this.password;
    }
    getRole() {
        return this.role;
    }
    getDescription() {
        return this.description;
    }
    getApproved() {
        const approvedBoolean = Boolean(this.approved);
        return approvedBoolean;
    }
}
exports.User = User;
exports.stringToUserRole = (input) => {
    switch (input) {
        case "PAYINGLISTENER":
            return UserRole.PAYINGLISTENER;
        case "UNPAYINGISTENER":
            return UserRole.UNPAYINGISTENER;
        case "ADMIN":
            return UserRole.ADMIN;
        case "BAND":
            return UserRole.BAND;
        default:
            throw new InvalidParameterError_1.InvalidParameterError("Invalid user role");
    }
};
var UserRole;
(function (UserRole) {
    UserRole["PAYINGLISTENER"] = "PAYINGLISTENER";
    UserRole["UNPAYINGISTENER"] = "UNPAYINGISTENER";
    UserRole["ADMIN"] = "ADMIN";
    UserRole["BAND"] = "BAND";
})(UserRole = exports.UserRole || (exports.UserRole = {}));
