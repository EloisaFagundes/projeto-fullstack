"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumRoutes = void 0;
const express_1 = __importDefault(require("express"));
const AlbumController_1 = require("../controller/AlbumController");
exports.albumRoutes = express_1.default.Router();
exports.albumRoutes.post("/register-album", new AlbumController_1.AlbumController().createAlbum);
exports.albumRoutes.get("/all-band-albuns", new AlbumController_1.AlbumController().getAlbunsByBandId);
