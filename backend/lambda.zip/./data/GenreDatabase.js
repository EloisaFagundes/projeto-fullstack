"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenreDatabase = void 0;
const BaseDatabase_1 = require("./BaseDatabase");
const Genre_1 = require("../model/Genre");
class GenreDatabase extends BaseDatabase_1.BaseDataBase {
    constructor() {
        super(...arguments);
        this.tableName = "GenreSpotenu";
    }
    toModel(dbModel) {
        return dbModel && new Genre_1.Genre(dbModel.id, dbModel.name);
    }
    getGenreByName(name) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this)
                .select("*")
                .from(this.tableName)
                .where({ name });
            return this.toModel(result[0]);
        });
    }
    getGenreById(id) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this)
                .select("*")
                .from(this.tableName)
                .where({ id });
            return this.toModel(result[0]);
        });
    }
    addMusicalGenre(genre) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.setConnection.call(this)
                .insert({
                id: genre.getId(),
                name: genre.getName(),
            })
                .into(this.tableName);
        });
    }
    getAllMusicalGenres() {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this).raw(`
    SELECT * FROM ${this.tableName} 
    `);
            return result[0].map((name) => this.toModel(name));
        });
    }
}
exports.GenreDatabase = GenreDatabase;
