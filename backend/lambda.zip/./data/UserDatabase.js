"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDatabase = void 0;
const BaseDatabase_1 = require("./BaseDatabase");
const User_1 = require("../model/User");
class UserDatabase extends BaseDatabase_1.BaseDataBase {
    constructor() {
        super(...arguments);
        this.tableName = "UserSpotenu";
    }
    toModel(dbModel) {
        return (dbModel &&
            new User_1.User(dbModel.id, dbModel.name, dbModel.email, dbModel.nickname, dbModel.password, dbModel.role, dbModel.approved, dbModel.description));
    }
    getUserByEmail(email) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this)
                .select("*")
                .from(this.tableName)
                .where({ email });
            return this.toModel(result[0]);
        });
    }
    getUserByNickname(nickname) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this)
                .select("*")
                .from(this.tableName)
                .where({ nickname });
            return this.toModel(result[0]);
        });
    }
    getUserById(id) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this)
                .select("*")
                .from(this.tableName)
                .where({ id });
            return this.toModel(result[0]);
        });
    }
    createBandUser(user) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.setConnection.call(this)
                .insert({
                id: user.getId(),
                name: user.getName(),
                email: user.getEmail(),
                nickname: user.getNickname(),
                password: user.getPassword(),
                role: user.getRole(),
                description: user.getDescription(),
                approved: user.getApproved(),
            })
                .into(this.tableName);
        });
    }
    createUserOrAdmin(user) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.setConnection.call(this)
                .insert({
                id: user.getId(),
                name: user.getName(),
                email: user.getEmail(),
                nickname: user.getNickname(),
                password: user.getPassword(),
                role: user.getRole(),
                approved: user.getApproved(),
            })
                .into(this.tableName);
        });
    }
    getAllBandsToBeApproved() {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.setConnection.call(this)
                .select("*")
                .from(this.tableName)
                .where({ role: "BAND" });
            return result.map((user) => this.toModel(user));
        });
    }
    approveBand(id) {
        const _super = Object.create(null, {
            setConnection: { get: () => super.setConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.setConnection.call(this).raw(`
         UPDATE ${this.tableName}
         SET approved = 1
         WHERE id= "${id}"
         `);
        });
    }
}
exports.UserDatabase = UserDatabase;
