"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumController = void 0;
const AlbumBusiness_1 = require("../business/AlbumBusiness");
const AlbumDatabase_1 = require("../data/AlbumDatabase");
const UserDatabase_1 = require("../data/UserDatabase");
const GenreDatabase_1 = require("../data/GenreDatabase");
const tokenGenerator_1 = require("../services/tokenGenerator");
const idGenerator_1 = require("../services/idGenerator");
let AlbumController = /** @class */ (() => {
    class AlbumController {
        createAlbum(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const { name, genresInfo } = req.body;
                const token = req.headers.authorization || req.headers.Authorization;
                try {
                    yield AlbumController.AlbumBusiness.createAlbum(token, name, genresInfo);
                    res.status(200).send({ message: "Álbum cadastrado com sucesso!" });
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        getAlbunsByBandId(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const token = req.headers.authorization || req.headers.Authorization;
                try {
                    const result = yield AlbumController.AlbumBusiness.getAlbunsByBandId(token);
                    res.status(200).send({ result });
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
    }
    AlbumController.AlbumBusiness = new AlbumBusiness_1.AlbumBusiness(new AlbumDatabase_1.AlbumDatabase(), new UserDatabase_1.UserDatabase(), new GenreDatabase_1.GenreDatabase(), new tokenGenerator_1.TokenGenerator(), new idGenerator_1.IdGenerator());
    return AlbumController;
})();
exports.AlbumController = AlbumController;
