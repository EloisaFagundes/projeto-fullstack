"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const UserBusiness_1 = require("../business/UserBusiness");
const UserDatabase_1 = require("../data/UserDatabase");
const hashGenerator_1 = require("../services/hashGenerator");
const tokenGenerator_1 = require("../services/tokenGenerator");
const idGenerator_1 = require("../services/idGenerator");
let UserController = /** @class */ (() => {
    class UserController {
        login(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const { nicknameOrEmail, password } = req.body;
                try {
                    const result = yield UserController.UserBusiness.login(nicknameOrEmail, password);
                    res.status(200).send(result);
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        signupBand(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const { name, email, nickname, password, description } = req.body;
                try {
                    const result = yield UserController.UserBusiness.signupBand(name, email, nickname, password, description);
                    res.status(200).send(result);
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        signupAdmin(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const { name, email, nickname, password } = req.body;
                const token = req.headers.authorization || req.headers.Authorization;
                try {
                    const result = yield UserController.UserBusiness.signupAdmin(name, email, nickname, password, token);
                    res.status(200).send(result);
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        signupUser(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const { name, email, nickname, password, role } = req.body;
                try {
                    const result = yield UserController.UserBusiness.signupUser(name, email, nickname, password, role);
                    res.status(200).send(result);
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        getAllBandsToBeApproved(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const token = req.headers.authorization || req.headers.Authorization;
                try {
                    const result = yield UserController.UserBusiness.getAllBandsToBeApproved(token);
                    res.status(200).send(result);
                }
                catch (err) {
                    console.log(err);
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        approveBand(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const token = req.headers.authorization || req.headers.Authorization;
                const id = req.params.id;
                try {
                    yield UserController.UserBusiness.approveBand(token, id);
                    res.status(200).send({
                        message: "Artista aprovado com sucesso!"
                    });
                }
                catch (err) {
                    console.log(err);
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
    }
    UserController.UserBusiness = new UserBusiness_1.UserBusiness(new UserDatabase_1.UserDatabase(), new hashGenerator_1.HashManager(), new tokenGenerator_1.TokenGenerator(), new idGenerator_1.IdGenerator());
    return UserController;
})();
exports.UserController = UserController;
