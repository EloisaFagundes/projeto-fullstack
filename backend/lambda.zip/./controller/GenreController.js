"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenreController = void 0;
const GenreBusiness_1 = require("../business/GenreBusiness");
const GenreDatabase_1 = require("../data/GenreDatabase");
const UserDatabase_1 = require("../data/UserDatabase");
const tokenGenerator_1 = require("../services/tokenGenerator");
const idGenerator_1 = require("../services/idGenerator");
let GenreController = /** @class */ (() => {
    class GenreController {
        addMusicalGenre(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const { name } = req.body;
                const token = req.headers.authorization || req.headers.Authorization;
                try {
                    yield GenreController.GenreBusiness.addMusicalGenre(name, token);
                    res.status(200).send({ message: "Gênero cadastrado com sucesso!" });
                }
                catch (err) {
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
        getAllMusicalGenres(req, res) {
            return __awaiter(this, void 0, void 0, function* () {
                const token = req.headers.authorization || req.headers.Authorization;
                try {
                    const result = yield GenreController.GenreBusiness.getAllMusicalGenres(token);
                    res.status(200).send(result);
                }
                catch (err) {
                    console.log(err);
                    res.status(err.errorCode || 400).send({ message: err.message });
                }
            });
        }
    }
    GenreController.GenreBusiness = new GenreBusiness_1.GenreBusiness(new UserDatabase_1.UserDatabase(), new GenreDatabase_1.GenreDatabase(), new tokenGenerator_1.TokenGenerator(), new idGenerator_1.IdGenerator());
    return GenreController;
})();
exports.GenreController = GenreController;
